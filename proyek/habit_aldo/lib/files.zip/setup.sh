#!/bin/bash
# ================================================================
# Habit Aldo - Project Setup Script
# Jalankan dari dalam folder habit_aldo/ (root project)
# ================================================================

echo "🌿 Setting up Habit Aldo project structure..."

# Buat folder struktur
mkdir -p lib/models
mkdir -p lib/providers
mkdir -p lib/screens
mkdir -p lib/widgets
mkdir -p lib/theme

echo "📁 Folder structure created."

# Pindahkan file dari lib/ ke subfolder masing-masing
# (asumsi semua file sudah ada di dalam lib/ flat)

# ── Models ──
for f in habit.dart habit.g.dart weight_entry.dart weight_entry.g.dart earning_entry.dart earning_entry.g.dart; do
  [ -f "lib/$f" ] && mv "lib/$f" "lib/models/$f" && echo "  ✓ models/$f"
done

# ── Providers ──
for f in habit_provider.dart weight_provider.dart earning_provider.dart; do
  [ -f "lib/$f" ] && mv "lib/$f" "lib/providers/$f" && echo "  ✓ providers/$f"
done

# ── Screens ──
for f in home_screen.dart habit_history_screen.dart earning_stats_screen.dart data_management_screen.dart; do
  [ -f "lib/$f" ] && mv "lib/$f" "lib/screens/$f" && echo "  ✓ screens/$f"
done

# ── Widgets ──
for f in habit_tile.dart weight_tracker_card.dart earning_tracker_card.dart day_confirm_dialog.dart streak_badge.dart; do
  [ -f "lib/$f" ] && mv "lib/$f" "lib/widgets/$f" && echo "  ✓ widgets/$f"
done

# ── Theme ──
for f in app_theme.dart; do
  [ -f "lib/$f" ] && mv "lib/$f" "lib/theme/$f" && echo "  ✓ theme/$f"
done

echo ""
echo "✅ All files moved successfully."
echo ""
echo "📦 Running flutter pub get..."
flutter pub get

echo ""
echo "🎉 Done! Run with: flutter run -d android"
echo "   Or for web: flutter run -d chrome"
echo "   Or for Windows: flutter run -d windows"
